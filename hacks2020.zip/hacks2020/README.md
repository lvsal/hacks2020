# hacks2020

The big boy repo for the team "Algorithm Peasants"

Surely this maginificant team will be able to conquer all and commit their big brains onto only the greatest of tasks.
